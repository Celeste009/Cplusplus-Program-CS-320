import java.util.HashMap;
import java.util.Map;

/**
 * A service class for managing contacts.
 */
public class ContactService {
    private final Map<String, Contact> contacts;

    /**
     * Constructs a new ContactService with an empty contacts map.
     */
    public ContactService() {
        this.contacts = new HashMap<>();
    }

    /**
     * Adds a new contact to the service.
     *
     * @param contact The contact to add.
     * @throws IllegalArgumentException if a contact with the same ID already exists.
     */
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact with ID " + contact.getContactId() + " already exists.");
        }
        contacts.put(contact.getContactId(), contact);
    }

    /**
     * Deletes a contact from the service.
     *
     * @param contactId The ID of the contact to delete.
     */
    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    /**
     * Updates an existing contact in the service.
     *
     * @param contactId      The ID of the contact to update.
     * @param updatedContact The updated contact object.
     * @throws IllegalArgumentException if the contact ID does not exist or if the contact ID cannot be updated.
     */
    public void updateContact(String contactId, Contact updatedContact) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact with ID " + contactId + " does not exist.");
        }
        if (!contactId.equals(updatedContact.getContactId())) {
            throw new IllegalArgumentException("Contact ID cannot be updated.");
        }
        contacts.put(contactId, updatedContact);
    }

    /**
     * Retrieves a contact from the service.
     *
     * @param contactId The ID of the contact to retrieve.
     * @return The contact object corresponding to the given ID, or null if not found.
     */
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
