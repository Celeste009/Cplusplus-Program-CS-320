/**
 * Represents a contact with basic information such as first name, last name,
 * phone number, and address.
 */
public class Contact {
	private final String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;

	/**
	 * Constructs a new Contact object with the specified information.
	 *
	 * @param contactId The unique identifier for the contact (maximum 10
	 *                  characters, non-null).
	 * @param firstName The first name of the contact (maximum 10 characters,
	 *                  non-null).
	 * @param lastName  The last name of the contact (maximum 10 characters,
	 *                  non-null).
	 * @param phone     The phone number of the contact (exactly 10 digits,
	 *                  non-null).
	 * @param address   The address of the contact (maximum 30 characters,
	 *                  non-null).
	 * @throws IllegalArgumentException if any of the parameters are invalid.
	 */
	public Contact(String contactId, String firstName, String lastName, String phone, String address) {
		// Parameter validation
		if (contactId == null || contactId.length() > 10) {
			throw new IllegalArgumentException("Contact ID must be a non-null string of maximum 10 characters.");
		}
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("First name must be a non-null string of maximum 10 characters.");
		}
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Last name must be a non-null string of maximum 10 characters.");
		}
		if (phone == null || !phone.matches("\\d{10}")) {
			throw new IllegalArgumentException("Phone must be a non-null string of exactly 10 digits.");
		}
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Address must be a non-null string of maximum 30 characters.");
		}

		// Initialize fields
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}

	/**
	 * Retrieves the contact's unique identifier.
	 *
	 * @return The contact's unique identifier.
	 */
	public String getContactId() {
		return contactId;
	}

	/**
	 * Retrieves the contact's first name.
	 *
	 * @return The contact's first name.
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the contact's first name.
	 *
	 * @param firstName The new first name for the contact (maximum 10 characters,
	 *                  non-null).
	 * @throws IllegalArgumentException if the first name is invalid.
	 */
	public void setFirstName(String firstName) {
		// Parameter validation
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("First name must be a non-null string of maximum 10 characters.");
		}
		this.firstName = firstName;
	}

	/**
	 * Retrieves the contact's last name.
	 *
	 * @return The contact's last name.
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the contact's last name.
	 *
	 * @param lastName The new last name for the contact (maximum 10 characters,
	 *                 non-null).
	 * @throws IllegalArgumentException if the last name is invalid.
	 */
	public void setLastName(String lastName) {
		// Parameter validation
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Last name must be a non-null string of maximum 10 characters.");
		}
		this.lastName = lastName;
	}

	/**
	 * Retrieves the contact's phone number.
	 *
	 * @return The contact's phone number.
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Sets the contact's phone number.
	 *
	 * @param phone The new phone number for the contact (exactly 10 digits,
	 *              non-null).
	 * @throws IllegalArgumentException if the phone number is invalid.
	 */
	public void setPhone(String phone) {
		// Parameter validation
		if (phone == null || !phone.matches("\\d{10}")) {
			throw new IllegalArgumentException("Phone must be a non-null string of exactly 10 digits.");
		}
		this.phone = phone;
	}

	/**
	 * Retrieves the contact's address.
	 *
	 * @return The contact's address.
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Sets the contact's address.
	 *
	 * @param address The new address for the contact (maximum 30 characters,
	 *                non-null).
	 * @throws IllegalArgumentException if the address is invalid.
	 */
	public void setAddress(String address) {
		// Parameter validation
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Address must be a non-null string of maximum 30 characters.");
		}
		this.address = address;
	}
}
