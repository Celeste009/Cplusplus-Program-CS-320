import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

	@Test
	public void testContactCreation() {
		// Regular contact creation test
		Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
		assertEquals("1234567890", contact.getContactId());
		assertEquals("John", contact.getFirstName());
		assertEquals("Doe", contact.getLastName());
		assertEquals("1234567890", contact.getPhone());
		assertEquals("123 Main St", contact.getAddress());
	}

	@Test
	public void testNullParameterContactCreation() {
		// Test null contactId
		assertThrows(IllegalArgumentException.class,
				() -> new Contact(null, "John", "Doe", "1234567890", "123 Main St"));
		// Test null firstName
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1234567890", null, "Doe", "1234567890", "123 Main St"));
		// Test null lastName
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1234567890", "John", null, "1234567890", "123 Main St"));
		// Test null phone
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1234567890", "John", "Doe", null, "123 Main St"));
		// Test null address
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1234567890", "John", "Doe", "1234567890", null));
	}

	@Test
	public void testNonValidParameterContactCreation() {
		// Test contactId exceeding maximum length
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St"));
		// Test firstName exceeding maximum length
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1234567890", "ElizabethLong", "Doe", "1234567890", "123 Main St"));
		// Test lastName exceeding maximum length
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1234567890", "John", "JohnsonLong", "1234567890", "123 Main St"));
		// Test phone with less than 10 digits
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1234567890", "John", "Doe", "12345", "123 Main St"));
		// Test phone with more than 10 digits
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1234567890", "John", "Doe", "123456789012", "123 Main St"));
		// Test address exceeding maximum length
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1234567890", "John", "Doe", "1234567890", "789 Maple St Very Long Address Name"));
	}

	@Test
	public void testSetFirstName() {
		// Test setting first name within the character limit
		Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
		contact.setFirstName("Jane");
		assertEquals("Jane", contact.getFirstName());

		// Test setting first name at maximum character limit and passing null
		assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("ElizabethLong"));
	}

	@Test
	public void testSetLastName() {
		// Test setting last name within the character limit
		Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
		contact.setLastName("Smith");
		assertEquals("Smith", contact.getLastName());

		// Test setting last name at maximum character limit and passing null
		assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setLastName("JohnsonLong"));
	}

	@Test
	public void testSetPhone() {
		// Test setting phone number with 10 digits
		Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
		contact.setPhone("0987654321");
		assertEquals("0987654321", contact.getPhone());

		// Test setting phone number with less than 10 digits, more than 10 digits and
		// passing null
		assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setPhone("12345"));
		assertThrows(IllegalArgumentException.class, () -> contact.setPhone("123456789012"));
	}

	@Test
	public void testSetAddress() {
		// Test setting address within the character limit
		Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
		contact.setAddress("456 Elm St");
		assertEquals("456 Elm St", contact.getAddress());

		// Test setting address at maximum character limit and passing null
		assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setAddress("789 Maple St Very Long Address Name"));
	}
}
