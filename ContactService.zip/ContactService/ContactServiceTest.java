import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        // Regular contact addition test
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("1234567890"));

        // Test adding a contact with an existing ID
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(contact));
    }

    @Test
    public void testDeleteContact() {
        // Regular contact deletion test
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.deleteContact("1234567890");
        assertNull(contactService.getContact("1234567890"));

        // Test deleting a non-existing contact
        assertDoesNotThrow(() -> contactService.deleteContact("NonExistingID"));
    }
    
    @Test
    public void testUpdateContact() {
        // Regular contact update test
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        Contact updatedContact = new Contact("1234567890", "Jane", "Smith", "0987654321", "456 Elm St");
        contactService.updateContact("1234567890", updatedContact);
        assertEquals("Jane", contactService.getContact("1234567890").getFirstName());
        assertEquals("Smith", contactService.getContact("1234567890").getLastName());
        assertEquals("0987654321", contactService.getContact("1234567890").getPhone());
        assertEquals("456 Elm St", contactService.getContact("1234567890").getAddress());

        // Test updating a non-existing contact
        Contact nonExistingContact = new Contact("8767345323", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contactService.updateContact("NonExistingID", nonExistingContact));

        // Test updating the contact ID (which should not be allowed)
        Contact updatedContactId = new Contact("0987654321", "Jane", "Smith", "0987654321", "456 Elm St");
        assertThrows(IllegalArgumentException.class, () -> contactService.updateContact("1234567890", updatedContactId));
    }
}
